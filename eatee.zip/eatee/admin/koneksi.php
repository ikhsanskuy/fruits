<?php 

    $koneksi = new mysqli ("localhost:8889", "root", "", "eatee");

?>